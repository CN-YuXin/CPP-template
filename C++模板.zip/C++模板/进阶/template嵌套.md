> ## [返回索引](../index.md)

template嵌套是C++17新增的语法，语法是:
`template <template <typename> typename T>`
这个里面的template可以说是把这个模板类型参数T变为了模板，tip: 此时只有这一个T参数，里面的template的那个typename可以加上参数名字虽然完全没有必要，因为它的作用只是说明传入的自定义类型的模板应该是什么样的，这个typename也可以改为class，这是在前几章就说过的

如果给这个T模板类型传入参数那么就必须传入一个自定义类型，且这个自定义类型必须是模板，模板参数只有一个类型参数(因为template嵌套的template的参数就有一个类型参数)，这个自定义类型的模板就如同刚才的template里面的template声明一样的模板:  
`template <typename>`

使用这个T类型也是跟模板一样需要传入参数这个就没什么好说的了

- 补充:
    1. template嵌套只能作用于类型参数，错误示范:
        ```
        template <template <typename> int T>
        void FN() {}
        ```
    2. template内部嵌套的template的模板参数如果有默认值那么意思不是传入的类型的模板的模板参数有这个默认实参，示例:
        ```
        template <typename>
        class L {};
        template <template <typename = int> typename T>
        class G {};
        ```
        这个G类的嵌套template的默认实参为int，不过这并没有任何用处甚至可以之间忽略掉，且在G类使用这个类型时也不会被这个int的默认实参影响到
    3. 嵌套template可以有默认实参:
        ```
        template <typemame>
        struct A {};
        template <template <typemame> typemame T = A>
        struct B {};
        ```
	1. 嵌套template可以是占位参数(即没有形参标识符)