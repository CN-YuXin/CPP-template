> ## [返回索引](../index.md)

此关键字是C++11引入的，用于一系列的编译时操作

- 修饰对象的特性:
	1. 必须立即初始化
	2. 必须是字面类型(字面类型见下文)
	3. 它的整个初始化表达式必须是常量表达式，常量表达式就是能在编译时计算出结果的表达式
- 修饰函数的特性:
	1. 函数不能是虚函数 (Until: C++20)
	2. 函数体不能是try语句块，例如`constexpr void FN() try {} catch(...) {}` (Until: C++20)
	3. 函数的返回值、形参的类型必须是字面类型，字面类型是以下之一:
		- \[void(可有CV限定)\] (C++14起)
		- 标量类型
		- 引用类型(即使被引用的类型不是标量类型)
		- 字面类型的数组
		- 类或结构体类型(可有CV限定)，并且满足下列所有条件:
			1. 拥有编译器默认提供的析构(因为编译器默认提供的析构可以视为constexpr的)，C++20起必须拥有被constexpr修饰的析构(因为C++20有这种语法)
			2. 下列之一(即第三个条件的满足条件就是满足下面任意一个条件):
				1. 是Lambda (C++17起)
				2. 是union(联合体)，且没有变体成员或有变体成员且有一个字面类型的变体成员不具有V限定
				3. 不是union，且它的每个匿名union成员(如果存在)没有变体成员或有一个不具有V限定的字面类型变体成员
				4. 至少拥有一个constexpr构造(可以是模板)且不是拷贝或移动构造，换句话说就是如果仅仅是拥有constexpr的拷贝或移动构造那么不满足字面类型的条件
	4. 如果此函数是非静态的成员函数那么会隐式附带const限定，例如`constexpr void fn()`等同于`constexpr void fn() const` (C++14前)
	5. 必须满足的条件:
		- C++14前函数只能有以下东西或函数是constexpr的函数声明:
			1. static_assert
			2. 空行(即分号)
			3. 不定义类或枚举的类型别名声明，错误示范例如`using T = class A {};`
			4. using
			5. 如果此函数不是构造函数那么必须有return
		- C++14后函数不能包含的东西(C++23前):
			1. try (C++20前)
			2. 内联ASM (C++20前)
			3. \[不初始化的变量(标量类型)\] (C++20前)
			4. 非字面类型的对象定义
			5. 静态与线程存储器的变量
			6. case、default、switch
- 修饰构造函数的特性(C++14起可修饰):
	- 若函数非= delete那么必须满足以下条件:
		1. 对于类和结构体的构造函数构造函数必须初始化每个(包含类内匿名类的成员，若是联合体那么要求只初始化此匿名联合体的一个非静态数据成员)非静态非变体的数据成员(若有默认值可以不初始化)并且要初始化基类对象
		2. 对于非空的联合体构造必须恰好初始化非静态一个成员
		3. 父类不能是虚基类(虚继承的父类)
		4. 构造所使用的成员的构造必须也是constexpr的，即使构造函数没有显式使用成员的构造(这种情况下成员所使用的构造也得是constexpr的)
- 补充:
	1. C++17起可用于if上:
		```
		if constexpr (/*条件*/) //(C++17引入)
		```
		这个用于在编译时判断(注: 和预处理的if不一样，这种if里面会进行语法检查，而预处理命令的if不会检查)，常见于模板元编程，if constexpr的判断条件必须是常量表达式(else if也可用)

		换个说法就是if constexpr在条件为假时不会编译只会进行语法检查，若if constexpr的条件为假且if constexpr内使用了模板B并且模板B在可以实例化情况下不会被推迟实例化则如同模板B被实例化一样对实例化后的模板进行语法检查(实际上由于if constexpr的条件为假模板B是绝不会被实例化的)，示例:

		```
		template <class T> struct A {using TY = decltype(T{}.fn());};
		template <class T>
		void fn() {
			if constexpr (false) {//
				A<T> t;//不会报错，因为没有对它进行语法检查
				//A<int> t2; 进行语法检查，而由于int没有成员函数fn所以它会报错
			}
		}
		```
		
		注: else if也可用constexpr
	2. if constexpr若在以下情况时，使用的模板类仍旧会被实例化:
		```
		if constexpr (...) {
			...
		}
		A<int> a;
		```
		无论上个if的条件是真是假都会被实例化(即使里面有return)，因为编译器觉得它可能会被使用，除非加上else才不会
	3. 当静态的成员变量为constexpr时此时这个就不是声明了而是定义(也就是不能再到类外定义了)此时必须直接初始化，例如:
		```
		class D {
		  public:
			constexpr static int value = 123;//必须直接初始化
		};
		```
		如果这个constexpr的成员不是静态的则会报错
	4. constexpr的指针例如`constexpr int* p = nullptr`的类型是`int*const`而不是`const int*`，这涉及到底层限定和顶层限定
	5. constexpr的引用和指针必须使用静态存储期的对象初始化(但可以不是常量表达式)
	6. 函数形参不可用constexpr
	7. 若函数具有constexpr则此函数可以返回常量表达式(实参合适的情况下)
	8. constexpr函数里的if如果满足if constexpr的条件那么它会隐式附带constexpr，也就是说if constexpr必须满足常量表达式，而constexpr函数里的if(不具有constexpr)只要可能满足常量表达式就行了
	9. 降级的隐式转换永远不符合常量表达式要求(例如long隐式转换为int)
	10. const的变量初始化为常量表达式那么这个变量满足常量表达式的要求(如果是基本数据类型的变量)，前提是它不是类的非静态数据成员，除非访问此成员的对象是constexpr的(此时此成员定义时的声明可以没有const):
		```
		struct A {
			bool r = true;//可以没有const，因为对象a是constexpr的
		};
		constexpr A a;
		```
		此时a.r满足常量表达式要求
	11. if constexpr的判断条件不能发生窄化的隐式转换
	12. 若一个对象要满足常量表达式那么它的析构与构造必须是constexpr或平凡的
	13. 右值引用引用字面量会发生拷贝，这个拷贝过程不满足常量表达式要求
	14. constexpr调用非constexpr的函数是非良构
	15. 如果定义一个constexpr的函数那么此函数的声明必须也有constexpr
	16. 前向声明的constexpr函数的返回值永远不满足常量表达式要求(详情见[核心常量表达式](核心常量表达式.md))
	17. 像const一样，constexpr不必加在最外面:
		```
		void constexpr fn() {//这是合法的，且等效于`constexpr void fn()`
		}
		```
	
- 功能测试宏:
	- \_\_cpp\_constexpr:
		(200704L) constexpr (Since: C++11) (Until: C++14)  
		(201304L) constexpr函数不再具有const限定 (Since: C++14) (Until: C++17)  
		(201603L) Lambda是否满足字面类型 (Since: C++17) (Until: C++20)
	- \_\_cpp\_constexpr\_in\_decltype(201711L) 是否允许常量表达式在decltype中出现